Log in to the live AWS environment using your credential

Begin by creating an EC2 key pair and saving it locally.

Create the Lambda function using this source code 

Apply this execution policy to the Lambda function.

Set the appropriate values for these environment variables in the Lambda function: AMI, INSTANCE_TYPE, KEY_NAME, SUBNET_ID.

Run a test for the Lambda function.

Connect to the new EC2 instance using SSH and the key pair you generated earlier.